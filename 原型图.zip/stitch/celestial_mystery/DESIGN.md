# Design System Document

## 1. Overview & Creative North Star

### Creative North Star: "The Celestial Oracle"
This design system moves away from the rigid, flat structures of typical social apps. Instead, it adopts the persona of a "Digital Oracle"—a mystical, layered experience that feels like peering into a star-lit abyss. 

To achieve a "High-End Editorial" feel for a Werewolf Mini Program, we utilize **intentional asymmetry** and **tonal depth**. Rather than placing elements in standard boxes, we treat the UI as a series of overlapping celestial planes. High-contrast manga illustrations break the bounds of their containers, creating a sense of life and "uncontained" power. We favor large, evocative typography scales and immersive "Glassmorphism" to ensure the interface feels like an artifact of a dark fantasy world rather than a mobile utility.

---

## 2. Colors

The color strategy is built on a foundation of "absolute depth," using charcoal and deep violet tones to allow the vibrant neon accents to "pop" with supernatural intensity.

### Palette Tokens
- **Base (Surface & Background):** `#0e0e0e` (Surface/Background). This is our "Void."
- **Primary (Neon Purple):** `#c09cff`. Used for high-priority celestial interactive elements.
- **Secondary (Solar Gold):** `#fdd400`. Reserved for "God" factions, legendary achievements, and critical alerts.
- **Tertiary (Blood Crimson):** `#ff725e`. Dedicated to the Werewolf faction and "Danger" states.

### The "No-Line" Rule
**Explicit Instruction:** Prohibit the use of 1px solid borders for sectioning. Structural boundaries must be defined solely through:
1.  **Background Color Shifts:** Placing a `surface-container-high` (`#20201f`) element on a `surface` (`#0e0e0e`) background.
2.  **Tonal Transitions:** Using subtle gradients to separate headers from body content.

### Surface Hierarchy & Nesting
Treat the UI as stacked sheets of obsidian. Use the `surface-container` tiers to create depth:
*   **Surface-Lowest (`#000000`):** Use for the deepest background or "dark mode" inactive areas.
*   **Surface-Low (`#131313`):** Standard page background.
*   **Surface-High (`#20201f`):** Primary card backgrounds.
*   **Surface-Highest (`#262626`):** Floating modals or highlighted interaction areas.

### The "Glass & Gradient" Rule
To add "soul" to the UI, all floating elements (modals, tooltips) should utilize **Glassmorphism**:
- Use `surface-variant` (`#262626`) at 60-80% opacity.
- Apply a `backdrop-blur` of 10px to 20px.
- **Signature Gradient:** For primary CTAs, transition from `primary` (`#c09cff`) to `primary-container` (`#b58bff`) at a 135-degree angle to simulate a glowing cosmic energy.

---

## 3. Typography

The typography scale balances the utilitarian needs of Chinese character readability with the evocative flair of "Space Grotesk" for display settings.

*   **Display (Space Grotesk):** Large, dramatic headings. Use `display-lg` (3.5rem) for faction reveals and game-over states to command the screen.
*   **Headlines (Space Grotesk):** Use `headline-sm` (1.5rem) for section titles. These should feel mystical—leverage the font's unique geometry to create an "Editorial" feel.
*   **Body (Manrope):** Optimized for readability in Chinese. Use `body-md` (0.875rem) for rule descriptions and chat logs. The clean sans-serif nature provides a necessary anchor to the more "chaotic" fantasy elements.
*   **Labels (Plus Jakarta Sans):** Use `label-sm` (0.6875rem) for metadata, such as player status or timestamps. These should be set in `on-surface-variant` (`#adaaaa`) to maintain hierarchy.

---

## 4. Elevation & Depth

We reject traditional drop shadows in favor of **Tonal Layering** and **Ambient Glows**.

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` background. This "sunken" or "raised" effect feels more organic to the manga aesthetic than a harsh shadow.
*   **Ambient Shadows:** For floating action buttons or character cards, use "Glow Shadows" instead of black shadows. Use the `primary` or `tertiary` color at 10% opacity with a blur radius of 24px to simulate a magical aura.
*   **The "Ghost Border" Fallback:** If a container requires more definition, use a "Ghost Border": the `outline-variant` token at **15% opacity**. Never use 100% opaque borders.
*   **Asymmetric Overlays:** Character illustrations (the "Anime" element) should frequently "break" the container. For example, a character's hair or weapon should overflow the top of a card to create a 3D effect.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary-container`), roundedness `full`, with a `secondary` (Gold) inner glow on hover/active states.
*   **Secondary:** Ghost style. Transparent background, `primary` "Ghost Border," and `on-surface` text.
*   **Tertiary:** No background. Bold `spaceGrotesk` text with an underline that only appears on active states.

### Faction Cards (Signature Component)
High-contrast containers using `surface-container-high`.
*   **Werewolf Card:** Background `surface-container-high` with a subtle `tertiary-dim` (`#e6190e`) radial gradient in the bottom corner.
*   **Villager Card:** Background `surface-container-high` with a `primary-dim` (`#b287fe`) radial gradient.
*   **Rule:** Forbid divider lines. Use vertical spacing (1.5rem) or a change to `surface-container-lowest` for nested lists within the card.

### Input Fields
*   **Base:** `surface-container-highest` background with a `none` border.
*   **Active State:** A `primary` (Neon Purple) "Ghost Border" (20% opacity) and a soft 4px `primary` outer glow.

### Interactive "Orbs" (Selection Chips)
Instead of standard chips, use circular icons with `surface-bright` backgrounds. When selected, they should "pulse" with a `secondary` (Gold) outer glow and scale up by 10%.

---

## 6. Do's and Don'ts

### Do
*   **Do** use extreme scale differences. A `display-lg` headline next to `body-sm` metadata creates a professional, editorial look.
*   **Do** leverage the "Anime" aesthetic by allowing character art to overlap text elements (ensuring legibility is maintained via text-shadows).
*   **Do** use `secondary_fixed` (Gold) sparingly—only for moments of victory or "Divine" intervention.

### Don't
*   **Don't** use standard 1px grey dividers (`#ccc`). Use a 24px vertical gap or a subtle background shift instead.
*   **Don't** use sharp corners. Stick to the `xl` (0.75rem) or `full` roundedness scale to keep the fantasy aesthetic feeling "magical" and fluid.
*   **Don't** use pure white (`#ffffff`) for long-form body text. Use `on-surface-variant` (`#adaaaa`) to reduce eye strain against the dark background.